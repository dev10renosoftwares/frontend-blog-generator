
import {
  HttpInterceptorFn,
  HttpErrorResponse
} from '@angular/common/http';

import {
  inject
} from '@angular/core';

import {
  catchError,
  switchMap,
  throwError
} from 'rxjs';

import {
  AuthService
} from '../core/services/auth';


export const authInterceptor: HttpInterceptorFn =
  (req, next) => {

    const authService = inject(AuthService);


    // =====================================================
    // PUBLIC REQUESTS
    // =====================================================
    // These APIs must NEVER receive an access token.
    // They must also NEVER trigger token refresh.
    // =====================================================

    const isPublicRequest =
      req.url.includes('/Auth/login') ||
      req.url.includes('/Auth/register') ||
      req.url.includes('/Auth/refresh-token') ||
      req.url.includes('/api/credits/pricing');


    // =====================================================
    // PUBLIC API
    // =====================================================
    // Send public requests exactly as they were created.
    // This is especially important for Credit Pricing.
    // =====================================================

    if (isPublicRequest) {

      console.log(
        'PUBLIC API REQUEST:',
        req.url
      );

      return next(req);
    }


    // =====================================================
    // GET ACCESS TOKEN
    // =====================================================

    const accessToken =
      authService.getToken();


    // =====================================================
    // NO TOKEN
    // =====================================================
    // If there is no token, simply send the request.
    // The backend will decide whether authentication
    // is required.
    // =====================================================

    if (!accessToken) {

      console.log(
        'NO ACCESS TOKEN:',
        req.url
      );

      return next(req);
    }


    // =====================================================
    // ADD AUTHORIZATION HEADER
    // =====================================================

    const authReq =
      req.clone({
        setHeaders: {
          Authorization:
            `Bearer ${accessToken}`
        }
      });


    console.log(
      'AUTHENTICATED API REQUEST:',
      req.url
    );


    // =====================================================
    // SEND REQUEST
    // =====================================================

    return next(authReq).pipe(

      catchError(
        (error: HttpErrorResponse) => {


          // ===============================================
          // ONLY HANDLE 401
          // ===============================================

          if (
            error.status !== 401
          ) {

            return throwError(
              () => error
            );
          }


          // ===============================================
          // DO NOT REFRESH AUTH REQUESTS
          // ===============================================

          if (isPublicRequest) {

            return throwError(
              () => error
            );
          }


          // ===============================================
          // ACCESS TOKEN EXPIRED
          // ===============================================

          console.log(
            'Access token expired. Refreshing token...'
          );


          // ===============================================
          // REFRESH TOKEN
          // ===============================================

          return authService
            .refreshToken()
            .pipe(

              switchMap(() => {


                // =========================================
                // GET NEW ACCESS TOKEN
                // =========================================

                const newAccessToken =
                  authService.getToken();


                if (!newAccessToken) {

                  console.error(
                    'New access token was not received.'
                  );

                  authService.logout();

                  return throwError(
                    () =>
                      new Error(
                        'New access token was not received.'
                      )
                  );
                }


                // =========================================
                // RETRY ORIGINAL REQUEST
                // =========================================

                const retryRequest =
                  req.clone({
                    setHeaders: {
                      Authorization:
                        `Bearer ${newAccessToken}`
                    }
                  });


                console.log(
                  'Retrying original request with new token:',
                  req.url
                );


                return next(
                  retryRequest
                );
              }),


              // =========================================
              // REFRESH FAILED
              // =========================================

              catchError(
                (refreshError) => {

                  console.error(
                    'Token refresh failed:',
                    refreshError
                  );


                  // =======================================
                  // LOG USER OUT
                  // =======================================

                  authService.logout();


                  return throwError(
                    () => refreshError
                  );
                }
              )
            );
        }
      )
    );
  };
