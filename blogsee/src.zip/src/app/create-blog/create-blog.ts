
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';

import { BlogService } from '../services/createblog';

@Component({
  selector: 'app-create-blog',
  standalone: true,

  imports: [
    CommonModule,
    FormsModule
  ],

  templateUrl: './create-blog.html',
  styleUrl: './create-blog.css'
})
export class CreateBlogComponent {

  // =====================================================
  // BLOG FORM
  // =====================================================

  blog = {
    language: '',
    category: '',
    tone: '',
    topic: '',
    audience: '',
    wordCount: null as number | null
  };


  // =====================================================
  // UI STATE
  // =====================================================

  isGenerating = false;
  showMessage = false;

  successMessage = '';
  errorMessage = '';


  // =====================================================
  // DROPDOWN OPTIONS
  // =====================================================

  categories = [
    'Technology',
    'Artificial Intelligence',
    'Education',
    'Business',
    'Health',
    'Lifestyle',
    'Travel',
    'Finance'
  ];

  tones = [
    'Professional',
    'Casual',
    'Friendly',
    'Academic',
    'Persuasive',
    'Creative'
  ];


  // =====================================================
  // CONSTRUCTOR
  // =====================================================

  constructor(
    private blogService: BlogService,
    private router: Router
  ) {}


  // =====================================================
  // GENERATE BLOG
  // =====================================================

  generateBlog(): void {

    // -----------------------------------------------
    // Reset messages
    // -----------------------------------------------

    this.errorMessage = '';
    this.successMessage = '';
    this.showMessage = false;


    // -----------------------------------------------
    // Basic validation
    // -----------------------------------------------

    if (
      !this.blog.language ||
      !this.blog.category ||
      !this.blog.tone ||
      !this.blog.topic ||
      !this.blog.audience ||
      !this.blog.wordCount
    ) {

      this.errorMessage =
        'Please fill in all the required fields.';

      this.showMessage = true;

      return;
    }


    // -----------------------------------------------
    // Convert language to backend enum
    //
    // IMPORTANT:
    // English = 0 is based on the validation error
    // you received. If Swagger shows another enum
    // value for English, change this value accordingly.
    // -----------------------------------------------

    let languageValue: number;

    switch (this.blog.language) {

      case 'English':
        languageValue = 0;
        break;

      case 'Hindi':
        languageValue = 1;
        break;

      case 'Urdu':
        languageValue = 2;
        break;

      default:
        languageValue = 0;
        break;
    }


    // -----------------------------------------------
    // Request body expected by backend
    //
    // Backend error said:
    // "The request field is required."
    //
    // Therefore the actual blog data needs to be
    // inside the "request" property.
    // -----------------------------------------------

    const requestBody = {

      request: {

        language: languageValue,

        category: this.blog.category,

        tone: this.blog.tone,

        topic: this.blog.topic,

        audience: this.blog.audience,

        wordCount: this.blog.wordCount

      }

    };


    // -----------------------------------------------
    // Debug
    // -----------------------------------------------

    console.log(
      'Generate Blog Request:',
      requestBody
    );


    // -----------------------------------------------
    // Start loading
    // -----------------------------------------------

    this.isGenerating = true;


    // -----------------------------------------------
    // Call BlogService
    // -----------------------------------------------

    this.blogService.generateBlog(requestBody).subscribe({

      // =============================================
      // SUCCESS
      // =============================================

      next: (response: any) => {

        console.log(
          'Generate Blog Response:',
          response
        );

        this.isGenerating = false;

        this.successMessage =
          'Blog generated successfully!';

        this.showMessage = true;


        // -------------------------------------------
        // Store generated blog
        // -------------------------------------------

        this.blogService.setGeneratedBlog(response);


        // -------------------------------------------
        // Navigate to generated blog page
        //
        // Change this route if your actual route
        // has a different name.
        // -------------------------------------------

        this.router.navigate(['/generated-blog']);

      },


      // =============================================
      // ERROR
      // =============================================

      error: (error: HttpErrorResponse) => {

        console.error(
          'Generate Blog API Error:',
          error
        );

        console.error(
          'Status:',
          error.status
        );

        console.error(
          'Backend validation errors:',
          error.error?.errors
        );

        console.error(
          'Full backend response:',
          error.error
        );


        // -------------------------------------------
        // Print individual validation errors
        // -------------------------------------------

        if (error.error?.errors) {

          Object.keys(error.error.errors).forEach(
            (key: string) => {

              console.error(
                `${key}:`,
                error.error.errors[key]
              );

            }
          );

        }


        // -------------------------------------------
        // Stop loading
        // -------------------------------------------

        this.isGenerating = false;


        // -------------------------------------------
        // Handle HTTP errors
        // -------------------------------------------

        if (error.status === 400) {

          this.errorMessage =
            'Invalid blog request. Please check your blog details.';

        }

        else if (error.status === 401) {

          this.errorMessage =
            'Your session has expired. Please log in again.';

        }

        else if (error.status === 402) {

          this.errorMessage =
            'You do not have enough credits to generate this blog.';

        }

        else if (error.status === 500) {

          this.errorMessage =
            'The server encountered an error while generating the blog.';

        }

        else {

          this.errorMessage =
            'Unable to generate the blog. Please try again.';

        }


        this.showMessage = true;

      }

    });

  }

}
