import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import { NavbarComponent } from '../../../../shared/components/navbar/navbar';
import { SidebarComponent } from '../../../../shared/components/sidebar/sidebar';
import { Router, RouterLink } from '@angular/router';

import { BlogService } from '../../../../services/blog';

@Component({
  selector: 'app-dashboard',

  standalone: true,

  imports: [
    CommonModule,
    NavbarComponent,
    SidebarComponent,
    RouterLink
  ],

  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.css'],
})
export class Dashboard implements OnInit {

  // =====================================================
  // BLOGS
  // =====================================================

  blogs: any[] = [];

  loadingBlogs = false;
  blogError = '';


  // =====================================================
  // CATEGORIES
  // =====================================================

  categories: any[] = [];

  loadingCategories = false;
  categoryError = '';


  // =====================================================
  // CONSTRUCTOR
  // =====================================================

  constructor(
    private router: Router,
    private blogService: BlogService
  ) {}


  // =====================================================
  // ON INIT
  // =====================================================

  ngOnInit(): void {

    // Load public blogs
    this.loadPublicFeed();

    // Load categories
    this.loadCategories();

  }


  // =====================================================
  // LOAD PUBLIC BLOG FEED
  // =====================================================

  loadPublicFeed(): void {

    this.loadingBlogs = true;
    this.blogError = '';

    this.blogService.getPublicFeed().subscribe({

      next: (response) => {

        console.log('Public Feed Response:', response);

        this.blogs = response;

        this.loadingBlogs = false;

      },

      error: (error) => {

        console.error('Public Feed Error:', error);

        this.blogError = 'Unable to load public blogs.';

        this.loadingBlogs = false;

      }

    });

  }


  // =====================================================
  // LOAD CATEGORIES
  // =====================================================

  loadCategories(): void {

    this.loadingCategories = true;
    this.categoryError = '';

    this.blogService.getCategories().subscribe({

      next: (response) => {

        console.log('Categories Response:', response);

        this.categories = response;

        this.loadingCategories = false;

      },

      error: (error) => {

        console.error('Categories Error:', error);

        this.categoryError = 'Unable to load categories.';

        this.loadingCategories = false;

      }

    });

  }


  // =====================================================
  // READ BLOG
  // =====================================================

  readBlog(): void {

    this.router.navigate(['/blog']);

  }

}