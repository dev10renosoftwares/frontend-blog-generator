
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { BlogService } from '../services/createblog';

@Component({
  selector: 'app-createprompt',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './createprompt.html',
  styleUrl: './createprompt.css'
})
export class Createprompt {

  /* =====================================================
     USER PROMPT
  ===================================================== */

  prompt = '';

  showValidation = false;

  isGenerating = false;


  /* =====================================================
     CONSTRUCTOR
  ===================================================== */

  constructor(
    private router: Router,
    private blogService: BlogService
  ) {}


  /* =====================================================
     USE QUICK SUGGESTION
  ===================================================== */

  useSuggestion(suggestion: string): void {

    this.prompt = suggestion;

    this.showValidation = false;
  }


  /* =====================================================
     REGENERATE
  ===================================================== */

  regenerate(): void {

    const trimmedPrompt = this.prompt.trim();

    if (!trimmedPrompt) {

      this.showValidation = true;

      return;
    }

    this.showValidation = false;

    this.isGenerating = true;


    /*
      Get the previously generated blog data.
    */

    const previousResponse =
      this.blogService.getGeneratedBlog();


    /*
      Keep the existing blog information and
      attach the user's regeneration prompt.
    */

    const previousData =
      previousResponse?.Data ??
      previousResponse?.data ??
      previousResponse ??
      {};


    const regenerateRequest = {

      ...previousData,

      prompt: trimmedPrompt,

      regenerationPrompt: trimmedPrompt

    };


    console.log(
      'Regeneration request:',
      regenerateRequest
    );


    /*
      At this point the request can be connected
      to the backend regeneration endpoint.

      For now we store the prompt together with
      the existing response so the integration flow
      remains intact.
    */

    this.blogService.setGeneratedBlog({

      ...previousResponse,

      regenerationPrompt: trimmedPrompt

    });


    /*
      Navigate back to the generated blog page.
    */

    setTimeout(() => {

      this.isGenerating = false;

      this.router.navigate(['/createdblog']);

    }, 500);
  }


  /* =====================================================
     CANCEL
  ===================================================== */

  cancel(): void {

    this.router.navigate(['/createdblog']);
  }

}

