
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BlogService {

  private readonly baseUrl =
    'http://192.168.29.14:5223/api/v1/AIBlog';


  // Stores the latest generated blog
  private generatedBlog: any = null;


  constructor(
    private http: HttpClient
  ) {}


  // =====================================================
  // GENERATE BLOG
  // =====================================================

  generateBlog(blogData: any): Observable<any> {

    console.log(
      'BlogService - Sending Request:',
      blogData
    );

    return this.http.post<any>(
      `${this.baseUrl}/generate`,
      blogData
    );

  }


  // =====================================================
  // STORE GENERATED BLOG
  // =====================================================

  setGeneratedBlog(response: any): void {

    this.generatedBlog = response;

  }


  // =====================================================
  // GET GENERATED BLOG
  // =====================================================

  getGeneratedBlog(): any {

    return this.generatedBlog;

  }


  // =====================================================
  // CLEAR GENERATED BLOG
  // =====================================================

  clearGeneratedBlog(): void {

    this.generatedBlog = null;

  }

}
