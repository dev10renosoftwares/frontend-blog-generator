import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  private readonly apiUrl =
    'http://192.168.29.71:5229/api/v1/Profile';

  constructor(private http: HttpClient) {}

  // ============================================================
  // GET PROFILE
  // GET /api/v1/Profile
  // ============================================================

  getProfile(): Observable<any> {

    return this.http.get<any>(
      this.apiUrl
    );
  }


  // ============================================================
  // UPDATE USERNAME
  // PUT /api/v1/Profile
  // ============================================================

  updateProfile(
    userName: string
  ): Observable<any> {

    return this.http.put<any>(
      this.apiUrl,
      {
        userName: userName.trim()
      }
    );
  }


  // ============================================================
  // UPLOAD PROFILE PICTURE
  // POST /api/v1/Profile/upload-picture
  // ============================================================

  uploadProfilePicture(
    file: File
  ): Observable<any> {

    const formData = new FormData();

    /*
     * IMPORTANT:
     *
     * The backend must receive the file using
     * the multipart/form-data field name "file".
     */
    formData.append(
      'file',
      file,
      file.name
    );

    /*
     * DO NOT set Content-Type manually here.
     *
     * Angular automatically creates:
     *
     * multipart/form-data;
     * boundary=----------------...
     *
     * when FormData is sent.
     */
    return this.http.post<any>(
      `${this.apiUrl}/upload-picture`,
      formData
    );
  }


  // ============================================================
  // DELETE PROFILE PICTURE
  // DELETE /api/v1/Profile/picture
  // ============================================================

  deleteProfilePicture(): Observable<any> {

    return this.http.delete<any>(
      `${this.apiUrl}/picture`
    );
  }


  // ============================================================
  // CHANGE PASSWORD
  // PUT /api/v1/Profile/change-password
  // ============================================================

  changePassword(
    CurrentPassword: string,
    NewPassword: string,
    ConfirmNewPassword: string
  ): Observable<any> {

    return this.http.put<any>(
      `${this.apiUrl}/change-password`,
      {
        CurrentPassword,
        NewPassword,
        ConfirmNewPassword
      }
    );
  }


  // ============================================================
  // DELETE ACCOUNT
  // DELETE /api/v1/Profile
  // ============================================================

  deleteAccount(
    reason: string
  ): Observable<any> {

    return this.http.request<any>(
      'DELETE',
      this.apiUrl,
      {
        body: {
          reason: reason.trim()
        }
      }
    );
  }

}