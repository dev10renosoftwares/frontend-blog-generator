
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import {
  Observable,
  BehaviorSubject,
  tap,
  throwError
} from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  // =====================================================
  // API URL
  // =====================================================

  private apiUrl =
    'http://192.168.29.14:5223/api/v1/Auth';


  // =====================================================
  // USER STATE
  // =====================================================

  private usernameSubject =
    new BehaviorSubject<string>(
      localStorage.getItem('username') || ''
    );

  username$ =
    this.usernameSubject.asObservable();

  public username =
    localStorage.getItem('username') || '';

  public userEmail =
    localStorage.getItem('userEmail') || '';

  public showAuthRequired = false;


  // =====================================================
  // CONSTRUCTOR
  // =====================================================

  constructor(
    private http: HttpClient
  ) {

    this.restoreUser();

  }


  // =====================================================
  // RESTORE USER AFTER PAGE REFRESH
  // =====================================================

  private restoreUser(): void {

    const savedUsername =
      localStorage.getItem('username');

    const savedEmail =
      localStorage.getItem('userEmail');

    const savedUser =
      localStorage.getItem('user');


    // ===================================================
    // RESTORE USERNAME
    // ===================================================

    if (savedUsername) {

      this.username =
        savedUsername;

      this.usernameSubject.next(
        savedUsername
      );

    }


    // ===================================================
    // RESTORE EMAIL
    // ===================================================

    if (savedEmail) {

      this.userEmail =
        savedEmail;

    }


    // ===================================================
    // RESTORE COMPLETE USER
    // ===================================================

    if (savedUser) {

      try {

        const user =
          JSON.parse(savedUser);


        this.username =
          user.userName ||
          user.username ||
          savedUsername ||
          '';


        this.userEmail =
          user.email ||
          savedEmail ||
          '';


        this.usernameSubject.next(
          this.username
        );


      } catch (error) {

        console.error(
          'Error restoring saved user:',
          error
        );

      }

    }

  }


  // =====================================================
  // UPDATE USERNAME EVERYWHERE
  // =====================================================

  updateStoredUsername(
    newUsername: string
  ): void {

    const username =
      newUsername.trim();


    if (!username) {
      return;
    }


    // ===================================================
    // UPDATE CLASS PROPERTY
    // ===================================================

    this.username =
      username;


    // ===================================================
    // UPDATE LOCAL STORAGE
    // ===================================================

    localStorage.setItem(
      'username',
      username
    );


    // ===================================================
    // UPDATE SAVED USER OBJECT
    // ===================================================

    const savedUser =
      localStorage.getItem('user');


    if (savedUser) {

      try {

        const user =
          JSON.parse(savedUser);


        user.userName =
          username;


        if (user.username) {

          user.username =
            username;

        }


        localStorage.setItem(
          'user',
          JSON.stringify(user)
        );


      } catch (error) {

        console.error(
          'Unable to update saved user:',
          error
        );

      }

    }


    // ===================================================
    // NOTIFY SUBSCRIBERS
    // ===================================================

    this.usernameSubject.next(
      username
    );

  }


  // =====================================================
  // LOGIN
  // =====================================================

  login(
    email: string,
    password: string
  ): Observable<any> {

    const loginData = {

      email: email,

      password: password

    };


    console.log(
      'LOGIN REQUEST:',
      {
        email: email
      }
    );


    return this.http.post<any>(
      `${this.apiUrl}/login`,
      loginData
    ).pipe(

      tap((response: any) => {

        console.log(
          'LOGIN RESPONSE received.'
        );


        this.saveAuthentication(
          response,
          email
        );

      })

    );

  }


  // =====================================================
  // REGISTER
  // =====================================================

  register(
    username: string,
    email: string,
    password: string
  ): Observable<any> {

    const registerData = {

      username: username,

      email: email,

      password: password

    };


    console.log(
      'REGISTER REQUEST:',
      {
        username: username,
        email: email
      }
    );


    return this.http.post<any>(
      `${this.apiUrl}/register`,
      registerData
    ).pipe(

      tap((response: any) => {

        console.log(
          'REGISTRATION RESPONSE received.'
        );


        this.saveAuthentication(
          response,
          email,
          username
        );

      })

    );

  }


  // =====================================================
  // SAVE LOGIN / REGISTER DATA
  // =====================================================

  private saveAuthentication(
    response: any,
    fallbackEmail: string,
    fallbackUsername: string = ''
  ): void {

    // ===================================================
    // GET DATA
    // ===================================================

    const data =
      response?.data || response;


    // ===================================================
    // GET USER
    // ===================================================

    const user =
      data?.user || data;


    // ===================================================
    // GET ACCESS TOKEN
    // ===================================================

    const accessToken =
      data?.accessToken ||
      response?.accessToken ||
      '';


    // ===================================================
    // GET REFRESH TOKEN
    // ===================================================

    const refreshTokenValue =
      data?.refreshToken ||
      response?.refreshToken ||
      '';


    // ===================================================
    // GET EXPIRES AT
    // ===================================================

    const expiresAt =
      data?.expiresAt ||
      response?.expiresAt ||
      '';


    // ===================================================
    // GET USERNAME
    // ===================================================

    const username =
      user?.userName ||
      user?.username ||
      data?.userName ||
      data?.username ||
      fallbackUsername ||
      '';


    // ===================================================
    // GET EMAIL
    // ===================================================

    const email =
      user?.email ||
      data?.email ||
      fallbackEmail ||
      '';


    // ===================================================
    // SAVE ACCESS TOKEN
    // ===================================================

    if (accessToken) {

      localStorage.setItem(
        'accessToken',
        accessToken
      );

      console.log(
        'JWT access token saved.'
      );

    } else {

      console.error(
        'WARNING: Access token was not found.'
      );

    }


    // ===================================================
    // SAVE REFRESH TOKEN
    // ===================================================

    if (refreshTokenValue) {

      localStorage.setItem(
        'refreshToken',
        refreshTokenValue
      );

      console.log(
        'Refresh token saved.'
      );

    } else {

      console.error(
        'WARNING: Refresh token was not found.'
      );

    }


    // ===================================================
    // SAVE EXPIRES AT
    // ===================================================

    if (expiresAt) {

      localStorage.setItem(
        'expiresAt',
        expiresAt
      );

    }


    // ===================================================
    // SAVE USERNAME
    // ===================================================

    this.username =
      username;

    localStorage.setItem(
      'username',
      username
    );


    // ===================================================
    // SAVE EMAIL
    // ===================================================

    this.userEmail =
      email;

    localStorage.setItem(
      'userEmail',
      email
    );


    // ===================================================
    // SAVE COMPLETE USER
    // ===================================================

    localStorage.setItem(
      'user',
      JSON.stringify(user)
    );


    // ===================================================
    // UPDATE USER STATE
    // ===================================================

    this.usernameSubject.next(
      username
    );


    console.log(
      'Authenticated user:',
      {
        username: username,
        email: email,
        hasAccessToken: !!accessToken,
        hasRefreshToken: !!refreshTokenValue
      }
    );

  }


  // =====================================================
  // REFRESH ACCESS TOKEN
  // =====================================================
  //
  // IMPORTANT:
  // This method does NOT accept a parameter.
  //
  // The refresh token is automatically read from
  // localStorage.
  //
  // This matches the interceptor:
  //
  // authService.refreshToken()
  //
  // =====================================================

  refreshToken(): Observable<any> {

    const savedRefreshToken =
      this.getRefreshToken();


    // ===================================================
    // CHECK REFRESH TOKEN
    // ===================================================

    if (!savedRefreshToken) {

      console.error(
        'No refresh token available.'
      );


      return throwError(
        () =>
          new Error(
            'Refresh token not found.'
          )
      );

    }


    console.log(
      'Refreshing access token...'
    );


    // ===================================================
    // CALL REFRESH TOKEN API
    // ===================================================

    return this.http.post<any>(
      `${this.apiUrl}/refresh-token`,
      {
        refreshToken: savedRefreshToken
      }
    ).pipe(

      tap((response: any) => {

        console.log(
          'Refresh token response received.'
        );


        // ===============================================
        // GET RESPONSE DATA
        // ===============================================

        const data =
          response?.data || response;


        // ===============================================
        // GET NEW ACCESS TOKEN
        // ===============================================

        const newAccessToken =
          data?.accessToken || '';


        // ===============================================
        // GET NEW REFRESH TOKEN
        // ===============================================

        const newRefreshToken =
          data?.refreshToken || '';


        // ===============================================
        // GET NEW EXPIRATION
        // ===============================================

        const newExpiresAt =
          data?.expiresAt || '';


        // ===============================================
        // SAVE NEW ACCESS TOKEN
        // ===============================================

        if (newAccessToken) {

          localStorage.setItem(
            'accessToken',
            newAccessToken
          );

          console.log(
            'New access token saved.'
          );

        }


        // ===============================================
        // SAVE NEW REFRESH TOKEN
        // ===============================================

        if (newRefreshToken) {

          localStorage.setItem(
            'refreshToken',
            newRefreshToken
          );

          console.log(
            'New refresh token saved.'
          );

        }


        // ===============================================
        // SAVE NEW EXPIRATION
        // ===============================================

        if (newExpiresAt) {

          localStorage.setItem(
            'expiresAt',
            newExpiresAt
          );

        }


        // ===============================================
        // UPDATE USERNAME
        // ===============================================

        if (data?.userName) {

          this.username =
            data.userName;


          localStorage.setItem(
            'username',
            data.userName
          );


          this.usernameSubject.next(
            data.userName
          );

        }


        // ===============================================
        // UPDATE EMAIL
        // ===============================================

        if (data?.email) {

          this.userEmail =
            data.email;


          localStorage.setItem(
            'userEmail',
            data.email
          );

        }


        // ===============================================
        // UPDATE USER OBJECT
        // ===============================================

        if (data?.userId) {

          const updatedUser = {

            userId:
              data.userId,

            userName:
              data.userName,

            email:
              data.email,

            role:
              data.role,

            availableCredits:
              data.availableCredits

          };


          localStorage.setItem(
            'user',
            JSON.stringify(updatedUser)
          );

        }


        console.log(
          'Access token refreshed successfully.'
        );

      })

    );

  }


  // =====================================================
  // GET ACCESS TOKEN
  // =====================================================

  getToken(): string | null {

    return localStorage.getItem(
      'accessToken'
    );

  }


  // =====================================================
  // GET REFRESH TOKEN
  // =====================================================

  getRefreshToken(): string | null {

    return localStorage.getItem(
      'refreshToken'
    );

  }


  // =====================================================
  // GET EXPIRATION TIME
  // =====================================================

  getExpiresAt(): string | null {

    return localStorage.getItem(
      'expiresAt'
    );

  }


  // =====================================================
  // GET SAVED USER
  // =====================================================

  getUser(): any {

    const user =
      localStorage.getItem('user');


    if (!user) {

      return null;

    }


    try {

      return JSON.parse(user);

    } catch {

      return null;

    }

  }


  // =====================================================
  // LOGIN CHECK
  // =====================================================

  isLoggedIn(): boolean {

    return !!localStorage.getItem(
      'accessToken'
    );

  }


  // =====================================================
  // LOGOUT
  // =====================================================

  logout(): void {

    this.username = '';

    this.userEmail = '';


    // ===================================================
    // REMOVE AUTHENTICATION DATA
    // ===================================================

    localStorage.removeItem(
      'accessToken'
    );

    localStorage.removeItem(
      'refreshToken'
    );

    localStorage.removeItem(
      'expiresAt'
    );


    // ===================================================
    // REMOVE USER DATA
    // ===================================================

    localStorage.removeItem(
      'username'
    );

    localStorage.removeItem(
      'user'
    );

    localStorage.removeItem(
      'userEmail'
    );


    // ===================================================
    // NOTIFY NAVBAR
    // ===================================================

    this.usernameSubject.next(
      ''
    );


    console.log(
      'User logged out.'
    );

  }


  // =====================================================
  // AUTH REQUIRED
  // =====================================================

  openAuthRequired(): void {

    this.showAuthRequired =
      true;

  }


  closeAuthRequired(): void {

    this.showAuthRequired =
      false;

  }

}
