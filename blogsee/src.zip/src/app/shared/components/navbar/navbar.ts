
import {
  Component,
  OnInit
} from '@angular/core';

import {
  CommonModule
} from '@angular/common';

import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators
} from '@angular/forms';

import {
  Router,
  RouterLink
} from '@angular/router';

import {
  HttpBackend,
  HttpClient,
  HttpHeaders
} from '@angular/common/http';

import {
  catchError,
  finalize,
  of,
  timeout
} from 'rxjs';

import {
  AuthService
} from '../../../core/services/auth';


// =====================================================
// CREDIT PRICING MODEL
// =====================================================

interface CreditPricing {

  serviceName: string;

  description: string;

  creditsRequired: number;

}


// =====================================================
// CREDIT PRICING RESPONSE
// =====================================================

interface CreditPricingResponse {

  success: boolean;

  message: string;

  data: CreditPricing[];

  errors: any;

}


@Component({
  selector: 'app-navbar',

  standalone: true,

  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink
  ],

  templateUrl: './navbar.html',

  styleUrls: ['./navbar.css']
})


export class Navbar implements OnInit {


  // =====================================================
  // API URLS
  // =====================================================

  private readonly API_URL =
    'http://192.168.29.71:5229/api/v1';


  /*
   * IMPORTANT:
   *
   * Credit pricing is NOT under /api/v1.
   *
   * Correct endpoint:
   *
   * GET /api/credits/pricing
   *
   */

  private readonly CREDIT_PRICING_URL =
    'http://192.168.29.71:5229/api/credits/pricing';


  // =====================================================
  // RAW HTTP CLIENT
  // =====================================================
  //
  // This HttpClient completely bypasses interceptors.
  //
  // We use it ONLY for public credit pricing.
  //
  // =====================================================

  private rawHttp: HttpClient;


  // =====================================================
  // AUTH POPUPS
  // =====================================================

  showLogin = false;

  showRegister = false;


  loginForm!: FormGroup;

  registerForm!: FormGroup;


  loginError = '';

  registerError = '';


  // =====================================================
  // USER STATE
  // =====================================================

  isLoggedIn = false;

  username = '';

  showUserMenu = false;


  // =====================================================
  // CREDIT STATE
  // =====================================================

  availableCredits = 0;

  creditPercentage = 0;


  // =====================================================
  // CREDIT PRICING STATE
  // =====================================================

  showCreditPricing = false;

  isLoadingCreditPricing = false;

  creditPricingError = '';

  creditPricing: CreditPricing[] = [];


  // =====================================================
  // CONSTRUCTOR
  // =====================================================

  constructor(

    private fb: FormBuilder,

    private http: HttpClient,

    private httpBackend: HttpBackend,

    private router: Router,

    private authService: AuthService

  ) {

    /*
     * Create a second HttpClient using HttpBackend.
     *
     * This bypasses authInterceptor completely.
     */

    this.rawHttp =
      new HttpClient(
        this.httpBackend
      );

  }


  // =====================================================
  // NG ON INIT
  // =====================================================

  ngOnInit(): void {


    // ===================================================
    // LOGIN FORM
    // ===================================================

    this.loginForm =
      this.fb.group({

        email: [
          '',
          [
            Validators.required,
            Validators.email
          ]
        ],

        password: [
          '',
          [
            Validators.required,
            Validators.minLength(6)
          ]
        ]

      });


    // ===================================================
    // REGISTER FORM
    // ===================================================

    this.registerForm =
      this.fb.group({

        username: [
          '',
          [
            Validators.required,
            Validators.minLength(3)
          ]
        ],

        email: [
          '',
          [
            Validators.required,
            Validators.email
          ]
        ],

        password: [
          '',
          [
            Validators.required,
            Validators.minLength(6)
          ]
        ]

      });


    // ===================================================
    // CHECK LOGIN
    // ===================================================

    this.checkLoginStatus();


    // ===================================================
    // GET CREDITS IF LOGGED IN
    // ===================================================

    if (this.isLoggedIn) {

      this.getAvailableCredits();

    }


    // ===================================================
    // USERNAME SUBSCRIPTION
    // ===================================================

    this.authService.username$.subscribe(
      (name: string | null) => {

        this.username =
          name || '';

      }
    );

  }


  // =====================================================
  // CHECK LOGIN STATUS
  // =====================================================

  checkLoginStatus(): void {

    const token =
      localStorage.getItem(
        'accessToken'
      );


    this.isLoggedIn =
      !!token;

  }


  // =====================================================
  // OPEN CREDIT PRICING
  // =====================================================

  openCreditPricing(): void {

    console.log(
      '===================================='
    );

    console.log(
      'OPENING CREDIT PRICING'
    );

    console.log(
      '===================================='
    );


    // ===================================================
    // OPEN POPUP
    // ===================================================

    this.showCreditPricing =
      true;


    // ===================================================
    // RESET OLD DATA
    // ===================================================

    this.creditPricing =
      [];

    this.creditPricingError =
      '';


    // ===================================================
    // SHOW LOADING
    // ===================================================

    this.isLoadingCreditPricing =
      true;


    // ===================================================
    // CALL API
    // ===================================================

    this.getCreditPricing();

  }


  // =====================================================
  // CLOSE CREDIT PRICING
  // =====================================================

  closeCreditPricing(): void {

    this.showCreditPricing =
      false;

  }


  // =====================================================
  // GET CREDIT PRICING
  // =====================================================

  getCreditPricing(): void {

    console.log(
      '===================================='
    );

    console.log(
      'REQUESTING CREDIT PRICING'
    );

    console.log(
      'URL:',
      this.CREDIT_PRICING_URL
    );

    console.log(
      '===================================='
    );


    // ===================================================
    // ALWAYS START LOADING
    // ===================================================

    this.isLoadingCreditPricing =
      true;

    this.creditPricingError =
      '';

    this.creditPricing =
      [];


    // ===================================================
    // RAW HTTP REQUEST
    // ===================================================
    //
    // IMPORTANT:
    //
    // rawHttp bypasses authInterceptor.
    //
    // Therefore:
    //
    // /api/credits/pricing
    //
    // goes directly to backend.
    //
    // ===================================================

    this.rawHttp
      .get<CreditPricingResponse>(
        this.CREDIT_PRICING_URL
      )
      .pipe(

        // ===============================================
        // TIMEOUT
        // ===============================================
        //
        // If backend does not respond within 10 seconds,
        // RxJS generates an error.
        //
        // This prevents infinite "Loading pricing..."
        //
        // ===============================================

        timeout(10000),


        // ===============================================
        // HANDLE ERROR
        // ===============================================

        catchError((error) => {

          console.error(
            '===================================='
          );

          console.error(
            'CREDIT PRICING API ERROR'
          );

          console.error(
            error
          );

          console.error(
            '===================================='
          );


          // =============================================
          // TIMEOUT ERROR
          // =============================================

          if (
            error?.name === 'TimeoutError'
          ) {

            this.creditPricingError =
              'Credit pricing request timed out. Please check the backend server.';

          }

          // =============================================
          // HTTP ERROR
          // =============================================

          else if (
            error?.status
          ) {

            this.creditPricingError =
              error?.error?.message ||
              `Unable to load credit pricing. HTTP ${error.status}`;

          }

          // =============================================
          // OTHER ERROR
          // =============================================

          else {

            this.creditPricingError =
              'Unable to load credit pricing. Please try again.';

          }


          /*
           * Return null so the subscription completes
           * normally instead of throwing another error.
           */

          return of(null);

        }),


        // ===============================================
        // ALWAYS STOP LOADING
        // ===============================================

        finalize(() => {

          console.log(
            'Credit pricing request finished.'
          );


          this.isLoadingCreditPricing =
            false;

        })

      )
      .subscribe({

        // =================================================
        // SUCCESS
        // =================================================

        next: (
          response:
            CreditPricingResponse | null
        ) => {

          console.log(
            '===================================='
          );

          console.log(
            'CREDIT PRICING RESPONSE'
          );

          console.log(
            response
          );

          console.log(
            '===================================='
          );


          // =============================================
          // NO RESPONSE
          // =============================================

          if (!response) {

            return;

          }


          // =============================================
          // SUCCESS RESPONSE
          // =============================================

          if (
            response.success === true &&
            Array.isArray(response.data)
          ) {

            this.creditPricing =
              response.data;


            this.creditPricingError =
              '';


            console.log(
              'CREDIT PRICING DATA:',
              this.creditPricing
            );

          }

          // =============================================
          // INVALID RESPONSE
          // =============================================

          else {

            this.creditPricing =
              [];


            this.creditPricingError =
              response.message ||
              'No credit pricing information found.';

          }

        }

      });

  }


  // =====================================================
  // GET AVAILABLE CREDITS
  // =====================================================

  getAvailableCredits(): void {

    const token =
      localStorage.getItem(
        'accessToken'
      );


    // ===================================================
    // NO TOKEN
    // ===================================================

    if (!token) {

      this.availableCredits =
        0;

      this.creditPercentage =
        0;

      return;

    }


    // ===================================================
    // HEADERS
    // ===================================================

    const headers =
      new HttpHeaders({

        'Content-Type':
          'application/json',

        'Authorization':
          `Bearer ${token}`

      });


    // ===================================================
    // CREDITS API
    // ===================================================

    this.http
      .get<any>(
        `${this.API_URL}/Credits`,
        {
          headers
        }
      )
      .subscribe({

        next: (response) => {

          console.log(
            'Credits response:',
            response
          );


          if (
            response &&
            response.success &&
            response.data
          ) {

            this.availableCredits =
              Number(
                response.data.availableCredits
              ) || 0;


            this.creditPercentage =
              Math.min(
                (
                  this.availableCredits /
                  100
                ) * 100,
                100
              );

          }

        },


        error: (error) => {

          console.error(
            'Credits API error:',
            error
          );

        }

      });

  }


  // =====================================================
  // OPEN LOGIN
  // =====================================================

  openLogin(): void {

    this.showLogin =
      true;

    this.showRegister =
      false;

    this.loginError =
      '';

  }


  // =====================================================
  // OPEN REGISTER
  // =====================================================

  openRegister(): void {

    this.showRegister =
      true;

    this.showLogin =
      false;

    this.registerError =
      '';

  }


  // =====================================================
  // CLOSE AUTH
  // =====================================================

  closeAuth(): void {

    this.showLogin =
      false;

    this.showRegister =
      false;

    this.loginError =
      '';

    this.registerError =
      '';

  }


  // =====================================================
  // SWITCH TO REGISTER
  // =====================================================

  switchToRegister(): void {

    this.showLogin =
      false;

    this.showRegister =
      true;

    this.loginError =
      '';

  }


  // =====================================================
  // SWITCH TO LOGIN
  // =====================================================

  switchToLogin(): void {

    this.showRegister =
      false;

    this.showLogin =
      true;

    this.registerError =
      '';

  }


  // =====================================================
  // LOGIN
  // =====================================================

  onLogin(): void {

    if (
      this.loginForm.invalid
    ) {

      this.loginForm.markAllAsTouched();

      return;

    }


    this.loginError =
      '';


    const loginData = {

      email:
        this.loginForm.value.email,

      password:
        this.loginForm.value.password

    };


    this.http
      .post<any>(
        `${this.API_URL}/Auth/login`,
        loginData
      )
      .subscribe({

        next: (response) => {

          console.log(
            'Login response:',
            response
          );


          // =========================================
          // SAVE ACCESS TOKEN
          // =========================================

          if (
            response?.accessToken
          ) {

            localStorage.setItem(
              'accessToken',
              response.accessToken
            );

          }


          // =========================================
          // SAVE REFRESH TOKEN
          // =========================================

          if (
            response?.refreshToken
          ) {

            localStorage.setItem(
              'refreshToken',
              response.refreshToken
            );

          }


          // =========================================
          // SAVE USERNAME
          // =========================================

          if (
            response?.user?.username
          ) {

            localStorage.setItem(
              'username',
              response.user.username
            );


            this.username =
              response.user.username;

          }


          // =========================================
          // UPDATE STATE
          // =========================================

          this.isLoggedIn =
            true;


          this.showLogin =
            false;


          this.loginForm.reset();


          // =========================================
          // GET CREDITS
          // =========================================

          this.getAvailableCredits();

        },


        error: (error) => {

          console.error(
            'Login error:',
            error
          );


          this.loginError =
            error?.error?.message ||
            'Invalid email or password.';

        }

      });

  }


  // =====================================================
  // REGISTER
  // =====================================================

  onRegister(): void {

    if (
      this.registerForm.invalid
    ) {

      this.registerForm.markAllAsTouched();

      return;

    }


    this.registerError =
      '';


    const registerData = {

      username:
        this.registerForm.value.username,

      email:
        this.registerForm.value.email,

      password:
        this.registerForm.value.password

    };


    this.http
      .post<any>(
        `${this.API_URL}/Auth/register`,
        registerData
      )
      .subscribe({

        next: (response) => {

          console.log(
            'Register response:',
            response
          );


          this.showRegister =
            false;

          this.showLogin =
            true;

          this.registerForm.reset();

        },


        error: (error) => {

          console.error(
            'Register error:',
            error
          );


          this.registerError =
            error?.error?.message ||
            'Registration failed. Please try again.';

        }

      });

  }


  // =====================================================
  // USER MENU
  // =====================================================

  toggleUserMenu(): void {

    this.showUserMenu =
      !this.showUserMenu;

  }


  // =====================================================
  // OPEN PROFILE
  // =====================================================

  openProfile(): void {

    this.showUserMenu =
      false;

    this.router.navigate([
      '/profile'
    ]);

  }


  // =====================================================
  // LOGOUT
  // =====================================================

  logout(): void {

    localStorage.removeItem(
      'accessToken'
    );

    localStorage.removeItem(
      'refreshToken'
    );

    localStorage.removeItem(
      'username'
    );


    this.isLoggedIn =
      false;

    this.username =
      '';

    this.availableCredits =
      0;

    this.creditPercentage =
      0;

    this.showUserMenu =
      false;


    this.router.navigate([
      '/'
    ]);

  }

}

